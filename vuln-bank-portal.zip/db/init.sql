CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL,
  role VARCHAR(30) DEFAULT 'user'
);

INSERT INTO users (username, password, role) VALUES
('alice', 'password123', 'user'),
('bob', 'letmein', 'user'),
('admin', 'adminpass', 'admin');

CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  account_number VARCHAR(20) NOT NULL,
  description VARCHAR(255),
  amount DECIMAL(10,2),
  txn_date DATE
);

INSERT INTO transactions (account_number, description, amount, txn_date) VALUES
('1234567890', 'POS Purchase - Grocery', 54.23, '2025-08-01'),
('1234567890', 'Salary Credit', 2500.00, '2025-08-05'),
('9876543210', 'Online Transfer', -150.00, '2025-08-09'),
('1111222233', 'ATM Withdrawal', -200.00, '2025-08-12'),
('1234567890', 'Utility Bill', -120.50, '2025-08-15');
