#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "[*] Starting vuln-bank-portal setup from ${PROJECT_DIR}"

if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  DOCKER_CMD="docker compose"
elif sudo docker compose version >/dev/null 2>&1; then
  DOCKER_CMD="sudo docker compose"
else
  echo "ERROR: docker compose not available. Install Docker and Docker Compose."
  exit 1
fi

$DOCKER_CMD down -v || true
$DOCKER_CMD build --no-cache
$DOCKER_CMD up -d

echo "[+] Stack started."
echo "Web app (login): http://10.1.1.4:8080"
echo "Vulnerable API: http://10.1.1.4:5000/api/users"
