const express = require('express');
const mysql = require('mysql');
const morgan = require('morgan');
const app = express();
app.use(express.json());
app.use(morgan('combined'));

const db = mysql.createConnection({
  host: 'db',
  user: 'bankuser',
  password: 'bankpass',
  database: 'bankdb'
});

app.get('/api/users', (req, res) => {
  db.query('SELECT id, username, role FROM users', (err, rows) => {
    if (err) return res.status(500).json({ error: 'db error' });
    res.json(rows);
  });
});

app.post('/api/updateRole', (req, res) => {
  const { username, role } = req.body || {};
  if (!username || !role) return res.status(400).json({ error: 'missing' });
  const sql = `UPDATE users SET role='${role}' WHERE username='${username}'`;
  db.query(sql, (err) => {
    if (err) return res.status(500).json({ error: 'db error' });
    res.json({ success: true });
  });
});

app.listen(5000, () => console.log('Vuln API listening on 5000'));
