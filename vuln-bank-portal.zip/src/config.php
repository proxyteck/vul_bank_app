<?php // PayXperience - lab config file ?>
<?php
$WINDOWS_SHARE = '\\192.168.56.3\BankData';
$WINDOWS_USER  = 'svc_bankapp';
$WINDOWS_PASS  = 'SvcB@nkP@ss!';
$WINDOWS_DOMAIN = 'corp.bank.local';

function read_win_creds($path) {
    if (!file_exists($path)) return null;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $out = [];
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($k,$v) = explode('=', $line, 2);
            $out[trim($k)] = trim($v);
        }
    }
    return $out;
}

$creds = read_win_creds(__DIR__ . '/win_creds.txt');
if ($creds) {
    $WINDOWS_USER = $creds['svc_user'] ?? $WINDOWS_USER;
    $WINDOWS_PASS = $creds['svc_pass'] ?? $WINDOWS_PASS;
    $WINDOWS_SHARE = '//' . ($creds['app_server'] ?? '192.168.56.3') . '/BankData';
}
?>
