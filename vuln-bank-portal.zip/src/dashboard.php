<?php
// Simple dashboard placeholder for PayXperience that shows recent transactions
$servername = "db";
$username = "bankuser";
$password = "bankpass";
$dbname = "bankdb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_GET['user'] ?? 'Customer';

// Fetch recent transactions (limit 10)
$txns = [];
$result = $conn->query("SELECT account_number, description, amount, txn_date FROM transactions ORDER BY txn_date DESC LIMIT 10");
if ($result) {
    while($row = $result->fetch_assoc()) {
        $txns[] = $row;
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>PayXperience - Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto; background:#0b1220; color:#e6eef8; margin:0; padding:40px; }
    .wrap { max-width:1000px; margin:0 auto; }
    header { display:flex; justify-content:space-between; align-items:center; }
    h1 { margin:0; font-size:24px; }
    .card { background:rgba(255,255,255,0.03); padding:20px; border-radius:10px; margin-top:20px; }
    a.btn { display:inline-block; padding:8px 12px; border-radius:8px; background:#06b6d4; color:#04202b; text-decoration:none; font-weight:600; }
    table { width:100%; border-collapse:collapse; margin-top:12px; }
    th, td { padding:10px; border-bottom:1px solid rgba(255,255,255,0.03); text-align:left; }
    th { color:rgba(230,238,248,0.8); }
    td.amount { text-align:right; }
    .pos { color:#34d399; } /* green */
    .neg { color:#fb7185; } /* red */
  </style>
</head>
<body>
  <div class="wrap">
    <header>
      <h1>PayXperience Dashboard</h1>
      <div><a class="btn" href="index.php">Logout</a></div>
    </header>
    <div class="card">
      <h2>Welcome, <?php echo htmlspecialchars($user); ?></h2>
      <p>Below are the most recent transactions across demo accounts.</p>
      <table aria-label="Recent transactions">
        <thead>
          <tr><th>Account</th><th>Description</th><th>Date</th><th style="text-align:right">Amount</th></tr>
        </thead>
        <tbody>
        <?php if (count($txns) === 0): ?>
          <tr><td colspan="4">No transactions found.</td></tr>
        <?php else: ?>
          <?php foreach($txns as $t): ?>
            <tr>
              <td><?php echo htmlspecialchars($t['account_number']); ?></td>
              <td><?php echo htmlspecialchars($t['description']); ?></td>
              <td><?php echo htmlspecialchars($t['txn_date']); ?></td>
              <td class="amount <?php echo ($t['amount'] >= 0) ? 'pos' : 'neg'; ?>"><?php echo number_format($t['amount'],2); ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
