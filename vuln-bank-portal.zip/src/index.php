<?php
$servername = "db";
$username = "bankuser";
$password = "bankpass";
$dbname = "bankdb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // Intentionally vulnerable (SQLi) - for lab only
    $sql = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    $res = $conn->query($sql);
    if ($res && $res->num_rows > 0) {
        // simple redirect to dashboard with username param (insecure, for lab demo)
        header('Location: dashboard.php?user=' . urlencode($user));
        exit;
    } else {
        $message = "Invalid username or password";
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>PayXperience - Login</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg1: #0f172a;
      --bg2: #0b1220;
      --card: rgba(255,255,255,0.04);
      --accent: #06b6d4;
      --text: #e6eef8;
    }
    html,body { height:100%; margin:0; font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; background: linear-gradient(135deg, var(--bg1), var(--bg2)); color:var(--text); }
    .center { min-height:100%; display:flex; align-items:center; justify-content:center; padding:40px; box-sizing:border-box; }
    .card { background: linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.02)); border-radius:12px; padding:32px; width:380px; box-shadow: 0 10px 30px rgba(2,6,23,0.6); border:1px solid rgba(255,255,255,0.03); }
    h1 { margin:0 0 8px 0; font-size:24px; font-weight:700; color:var(--text); }
    p.lead { margin:0 0 18px 0; color:rgba(230,238,248,0.8); }
    label { display:block; margin-bottom:6px; font-size:13px; color:rgba(230,238,248,0.85); }
    input[type=text], input[type=password] { width:100%; padding:10px 12px; margin-bottom:12px; border-radius:8px; border:1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.02); color:var(--text); box-sizing:border-box; }
    button { width:100%; padding:10px 12px; border-radius:8px; border:none; background: linear-gradient(90deg, var(--accent), #0ea5a4); color:#04202b; font-weight:600; cursor:pointer; }
    .msg { margin-top:12px; color:#ffccd5; }
    .footer { margin-top:16px; font-size:12px; color:rgba(230,238,248,0.6); text-align:center; }
    a.brand { color:var(--accent); text-decoration:none; font-weight:700; }
  </style>
</head>
<body>
  <div class="center">
    <div class="card" role="main" aria-labelledby="title">
      <h1 id="title">PayXperience</h1>
      <p class="lead">Secure online banking portal</p>
      <form method="post" action="">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" autocomplete="username" required />
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required />
        <button type="submit">Sign in</button>
      </form>
      <?php if ($message): ?>
        <div class="msg"><?php echo htmlspecialchars($message); ?></div>
      <?php endif; ?>
      <div class="footer">Powered by <a class="brand" href="#">PayXperience</a></div>
    </div>
  </div>
</body>
</html>
