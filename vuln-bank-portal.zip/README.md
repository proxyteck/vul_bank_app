# vuln-bank-portal - PayXperience lab

This lab is intentionally insecure. Run in isolated environment.

Services:
- Web: PayXperience PHP app (http://10.1.1.4:8080)
- API: Vulnerable Node.js API (http://10.1.1.4:5000)
- DB: MySQL 5.7 (bankdb)

Run:
chmod +x setup.sh
./setup.sh
